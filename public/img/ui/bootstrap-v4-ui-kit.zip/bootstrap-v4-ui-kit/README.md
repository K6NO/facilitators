# Bootstrap-V4-Uikit

Bootstrap-V4-Uikit by ZTfer

个人微博： [@ZTfer](http://weibo.com/wudu2012)

个人博客： [www.ztfer.com](http://www.ztfer.com)

邮箱：duke2007@163.com

### 说明

- bootstrap v4.0 uikit
- 包含bootstrap中所有组件，部分预览见下图

### 预览

![Media-Object](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Media%20Object.png)
![Reboot](https://github.com/ZTfer/Bootstrap-V4-Uikit/blob/master/img/Reboot.png)
![Typography](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Typography.png)
![Code](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Code.png)

![Tables](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Tables.png)
![Figures](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Figures.png)
![Buttons](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Buttons.png)

![Buttons Dorpdown](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Button%20dropdown.png)
![Forms](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Forms.png)
![Input-group](https://github.com/ZTfer/Bootstrap-V4-Uikit/blob/master/img/Input%20group.png)
![Dropdowns](https://github.com/ZTfer/Bootstrap-V4-Uikit/blob/master/img/Dropdowns.png)
![Labels](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Labels.png)
![Alerts](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Alerts.png)
![Labels](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Labels.png)
![Cards](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Cards.png)
![Navs](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Navs.png)
![Navbar](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Navbar.png)
![Breadcrumb](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Breadcrumb.png)
![Pagination](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Pagination.png)
![Progress](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Progress.png)
![List-group](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/List%20group.png)
![Modal](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Modal.png)
![Scrollspy&Tooltips](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Scrollspy%20%26%20Tooltips.png)
![Popover&Collapse](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Popover%20Collapse.png)
![Carousel](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Carousel.png)
![Utility-classes](https://raw.githubusercontent.com/ZTfer/Bootstrap-V4-Uikit/master/img/Utility%20classes.png)



### 更新记录

- 2016.01.02 创建项目 Media Object，Reboot
- 2016.01.03 Typography，Code，Images
- 2016.01.04 Table,Figure
- 2016.01.05 Buttons
- 2016.01.06 Button Group
- 2016.01.07 Button dropdown
- 2016.01.09 Forms
- 2016.01-10 Input-group Dropdowns Jumbptron Labels Alerts
- 2016.01.11 Cards
- 2016.01.12 Navs Navbar Breadcrumb Pagination Progress
- 2016.01.13 List group
- 2016.01.14 Modal Scrollspy Tooltips Popovers Collapse Carousel Utility classes